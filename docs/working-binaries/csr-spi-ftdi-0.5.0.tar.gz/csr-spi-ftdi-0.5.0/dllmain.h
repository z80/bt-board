#ifndef _DLLMAIN_H
#define _DLLMAIN_H

extern uint32_t pttrans_api_version;

#endif
